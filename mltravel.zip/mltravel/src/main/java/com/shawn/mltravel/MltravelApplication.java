package com.shawn.mltravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MltravelApplication {

    public static void main(String[] args) {
        SpringApplication.run(MltravelApplication.class, args);
    }

}

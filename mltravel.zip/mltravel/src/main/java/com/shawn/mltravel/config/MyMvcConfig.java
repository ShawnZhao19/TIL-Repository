package com.shawn.mltravel.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MyMvcConfig implements WebMvcConfigurer {
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("travel/admin/login");
        registry.addViewController("login.html").setViewName("travel/admin/login");
        registry.addViewController("admin.html").setViewName("travel/admin/index");
        registry.addViewController("welcome.html").setViewName("travel/admin/welcome");
    }


    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new LoginAdminHandlerInterceptor()).addPathPatterns("/**").
                excludePathPatterns("/","/admin/login","/login.html","/css/**","/fonts/**","/images/**","/js/**","/lib/**");
    }
}

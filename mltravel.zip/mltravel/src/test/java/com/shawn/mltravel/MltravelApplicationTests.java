package com.shawn.mltravel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MltravelApplicationTests {

    @Test
    void contextLoads() {
    }

}
